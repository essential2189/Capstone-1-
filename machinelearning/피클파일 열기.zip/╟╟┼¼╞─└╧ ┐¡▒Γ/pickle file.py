import pickle
with open(r"C:\Users\sengj\Desktop\naver-nlp-challenge-2018-master\korean_en.pkl","rb") as fr:
    data = pickle.load(fr)
print(data)

